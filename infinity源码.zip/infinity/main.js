(function () {
    const sourceList = document.getElementById('sourceList');
    const searchBtn = document.getElementById('searchBtn');
    const kwInput = document.getElementById('kwInput');
    const mainContent = document.getElementById('mainContent');
    const scopeBtn = document.getElementById('scopeBtn');
    const modeBtn = document.getElementById('modeBtn');
    const homeTitle = document.getElementById('homeTitle');
    const toggleSourceBtn = document.getElementById('toggleSourceBtn');
    const sourceSelectMask = document.getElementById('sourceSelectMask');
    const clearBtn = document.getElementById('clearBtn');

    /* ================= 状态 ================= */
    let currentMode = 'loose';      // loose 宽松 / strict 严格
    let searchScope = 'current';    // current 当前资源 / all 全站搜索
    let currentPage = 1;
    const PAGE_SIZE = 20;
    const TOAST_MS = 2200;

    let fakeMovies = [];
    let currentTxtName = '';
    let currentSourceName = '';
    let currentList = [];
    let currentKw = '';
    let sourceItems = [];

    const txtCache = {};
    let siteGroups = [];
    let activeGroupIdx = 0;

    function modeLabel() {
        return currentMode === 'strict' ? '严格' : '宽松';
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function cleanName(s) {
        return String(s == null ? '' : s).replace(/[\s\u3000]+/g, '').trim();
    }

    function splitName(name) {
        const raw = String(name == null ? '' : name);
        const m = raw.match(/^(.{1,12}?)[-－—–](.+)$/);
        if (m) return { type: m[1].trim(), title: m[2].trim() };
        return { type: '', title: raw.trim() };
    }

    /* ================= 轻提示 ================= */
    let toastEl = null;
    let toastTimer = null;
    function showToast(msg) {
        if (!toastEl) {
            toastEl = document.createElement('div');
            toastEl.className = 'app-toast';
            document.body.appendChild(toastEl);
        }
        toastEl.textContent = msg;
        void toastEl.offsetWidth;
        toastEl.classList.add('show');
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(() => toastEl.classList.remove('show'), TOAST_MS);
    }

    /* ================= 数据读取 ================= */
    function parseMovieLine(line) {
        const text = String(line == null ? '' : line).replace(/^\uFEFF/, '').trim();
        if (!text) return null;
        const m = text.match(/^([^,，|]+)[,，|](.+)$/);
        if (!m) return null;
        const name = m[1].trim();
        const url = m[2].trim();
        if (!name || !url || url === '#genre#') return null;
        return { name, url };
    }

    // 直接读取文件
    async function loadTxtMovies(txtName) {
        if (!txtName) return [];
        if (txtName in txtCache) return txtCache[txtName];
        try {
            const resp = await fetch('sources/' + encodeURIComponent(txtName));
            if (!resp.ok) { txtCache[txtName] = []; return []; }
            const text = await resp.text();
            const list = text.split(/\r?\n/).map(parseMovieLine).filter(Boolean);
            txtCache[txtName] = list;
            return list;
        } catch (err) {
            txtCache[txtName] = [];
            return [];
        }
    }

    async function loadCurrentMovies() {
        fakeMovies = await loadTxtMovies(currentTxtName);
        currentPage = 1;
        renderMovieList(fakeMovies);
    }

    /* ================= 高亮 ================= */
    function activeSourceCard(card) {
        document.querySelectorAll('.source-card').forEach(item => item.classList.remove('active'));
        if (card) card.classList.add('active');
    }

    /* ================= 分页 ================= */
    function clampPage(total) {
        const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
        if (!currentPage || currentPage > totalPages) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;
    }

    function renderPageBar(total) {
        const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
        if (currentPage > totalPages) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;
        return [
            '<div class="page-bar">',
            '<button type="button" class="page-btn" id="prevPage"', (currentPage <= 1 ? ' disabled' : ''), '>上一页</button>',
            '<span>', currentPage, '/', totalPages, '</span>',
            '<div class="page-jump">',
            '<input class="page-input" id="jumpPage" type="number" min="1" max="', totalPages, '" placeholder="页码">',
            '<button type="button" class="page-btn" id="jumpBtn">跳转</button>',
            '</div>',
            '<button type="button" class="page-btn" id="nextPage"', (currentPage >= totalPages ? ' disabled' : ''), '>下一页</button>',
            '</div>'
        ].join('');
    }

    function bindPageBar(total, gotoPage) {
        const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
        const prev = document.getElementById('prevPage');
        const next = document.getElementById('nextPage');
        const jumpBtn = document.getElementById('jumpBtn');
        const jumpInput = document.getElementById('jumpPage');

        if (prev) prev.onclick = () => gotoPage(Math.max(1, currentPage - 1));
        if (next) next.onclick = () => gotoPage(Math.min(totalPages, currentPage + 1));
        const doJump = () => {
            let page = parseInt(jumpInput.value, 10);
            if (isNaN(page)) return;
            page = Math.max(1, Math.min(totalPages, page));
            gotoPage(page);
        };
        if (jumpBtn) jumpBtn.onclick = doJump;
        if (jumpInput) jumpInput.onkeydown = e => { if (e.key === 'Enter') doJump(); };
    }

    /* ================= 列表渲染 ================= */
    function movieRows(list) {
        const start = (currentPage - 1) * PAGE_SIZE;
        const pageList = list.slice(start, start + PAGE_SIZE);
        return pageList.map(item => {
            const parts = splitName(item.name);
            const tag = parts.type ? '<span class="movie-type">' + esc(parts.type) + '</span>' : '';
            return '<div class="movie-row" data-name="' + esc(item.name) + '">' +
                       '<span class="movie-name">' + esc(parts.title) + '</span>' +
                       tag +
                   '</div>';
        }).join('');
    }

    function buildTitle(kw, total) {
        const key = kw ? '<span class="small-key">' + esc(kw) + '</span>' : '';
        return '<div class="search-result-title">' + esc(currentSourceName) + '-' + modeLabel() + ':' +
               key + '<span class="count">(' + total + '条)</span></div>' +
               '<div class="title-divider"></div>';
    }

    function renderMovieList(list, page) {
        currentList = list;
        currentKw = kwInput.value.trim();
        if (typeof page === 'number') currentPage = page;
        if (!list.length) {
            mainContent.innerHTML = buildTitle('', 0) + '<div class="empty-tip">暂无影片</div>';
            return;
        }
        clampPage(list.length);
        mainContent.innerHTML =
            buildTitle('', list.length) +
            '<div class="movie-list">' + movieRows(list) + '</div>' +
            renderPageBar(list.length);

        bindPageBar(list.length, gotoPage => {
            currentPage = gotoPage;
            renderMovieList(currentList, currentPage);
            window.scrollTo(0, 0);
        });
    }

    /* ================= 搜索 ================= */
    function parseKeywords(kw) {
        return kw.split('+').map(s => s.trim()).filter(Boolean);
    }

    function matchMovie(name, keywords, mode) {
        const title = splitName(name).title.toLowerCase();
        const hit = keywords.map(word => title.includes(word.toLowerCase()));
        return mode === 'strict' ? hit.every(Boolean) : hit.some(Boolean);
    }

    function renderSearchResult(kw, page) {
        currentKw = kw;
        if (typeof page === 'number') currentPage = page;
        const keywords = parseKeywords(kw);
        const result = fakeMovies.filter(item => matchMovie(item.name, keywords, currentMode));
        if (!result.length) {
            mainContent.innerHTML = buildTitle(kw, 0) + '<div class="empty-tip">没有找到匹配影片</div>';
            return;
        }
        clampPage(result.length);
        mainContent.innerHTML =
            buildTitle(kw, result.length) +
            '<div class="movie-list">' + movieRows(result) + '</div>' +
            renderPageBar(result.length);

        bindPageBar(result.length, gotoPage => {
            currentPage = gotoPage;
            renderSearchResult(currentKw, currentPage);
            window.scrollTo(0, 0);
        });
    }

    let siteSearchSeq = 0;
    async function runSiteSearch(kw, page) {
        const seq = ++siteSearchSeq;
        if (typeof page === 'number') currentPage = page;
        currentKw = kw;
        mainContent.innerHTML = '<div class="empty-tip">正在检索全部资源…</div>';
        const keywords = parseKeywords(kw);
        const cards = [].slice.call(sourceList.querySelectorAll('.source-card'));
        const groups = await Promise.all(cards.map(card => {
            const name = cleanName(card.querySelector('.card-text').textContent);
            const txt = card.dataset.txt || '';
            return loadTxtMovies(txt).then(movies => ({
                name: name, txt: txt, movies: movies,
                hit: movies.filter(item => matchMovie(item.name, keywords, currentMode))
            }));
        }));

        if (seq !== siteSearchSeq) return;
        siteGroups = groups;
        if (!groups[activeGroupIdx] || !groups[activeGroupIdx].hit.length) {
            let idx = -1;
            for (let i = 0; i < groups.length; i++) {
                if (groups[i].hit.length) { idx = i; break; }
            }
            activeGroupIdx = idx >= 0 ? idx : 0;
        }
        renderSiteResult(kw);
    }

    function fitGroupCards() {
        const MIN_SIZE = 9, MAX_SIZE = 12;
        mainContent.querySelectorAll('.group-card').forEach(card => {
            const name = card.querySelector('.gc-name');
            const count = card.querySelector('.gc-count');
            if (!name) return;
            const apply = size => {
                card.style.setProperty('font-size', size + 'px', 'important');
                name.style.setProperty('font-size', size + 'px', 'important');
                if (count) count.style.setProperty('font-size', size + 'px', 'important');
            };
            let size = MAX_SIZE;
            apply(size);
            while (size > MIN_SIZE && (name.scrollWidth > name.clientWidth + 1 || card.scrollWidth > card.clientWidth + 1)) {
                size -= 0.5; apply(size);
            }
        });
    }

    function renderSiteResult(kw) {
        const cardsHtml = siteGroups.map((g, i) =>
            '<div class="group-card' + (i === activeGroupIdx ? ' active' : '') + '" data-idx="' + i + '">' +
                '<span class="gc-name">' + esc(g.name) + '</span>' +
                '<span class="gc-count">(' + g.hit.length + ')</span>' +
            '</div>'
        ).join('');
        const group = siteGroups[activeGroupIdx];
        if (group && group.hit.length) clampPage(group.hit.length);
        let bodyHtml;
        if (!group || !group.hit.length) {
            bodyHtml = '<div class="group-divider"></div><div class="empty-tip">没有找到匹配影片</div>';
        } else {
            bodyHtml = '<div class="group-divider"></div>' +
                '<div class="movie-list">' + movieRows(group.hit) + '</div>' +
                renderPageBar(group.hit.length);
        }

        mainContent.innerHTML =
            '<div class="search-result-title">全站搜索-' + modeLabel() + ':' +
                '<span class="small-key">' + esc(kw) + '</span>' +
            '</div>' +
            '<div class="group-cards">' + cardsHtml + '</div>' +
            bodyHtml;

        fitGroupCards();
        mainContent.querySelectorAll('.group-card').forEach(el => {
            el.onclick = () => {
                activeGroupIdx = parseInt(el.dataset.idx, 10);
                currentPage = 1;
                renderSiteResult(currentKw);
            };
        });
        if (group && group.hit.length) {
            bindPageBar(group.hit.length, gotoPage => {
                currentPage = gotoPage;
                renderSiteResult(currentKw);
                window.scrollTo(0, 0);
            });
        }
    }

    function doSearch() {
        const kw = kwInput.value.trim();
        if (!kw) { showToast('请输入关键词'); return; }
        currentPage = 1;
        activeGroupIdx = 0;
        if (searchScope === 'all') {
            runSiteSearch(kw);
        } else {
            mainContent.innerHTML = '<div class="loading-tip">正在检索当前资源…</div>';
            setTimeout(() => renderSearchResult(kw), 0);
        }
    }

    /* ================= 播放跳转 ================= */
    function openPlayPage(item) {
        const url = new URL('play.html', location.href);
        url.searchParams.set('name', item.name);
        url.searchParams.set('url', item.url || '');
        location.href = url.toString();
    }

    document.body.addEventListener('click', e => {
        const row = e.target.closest('.movie-row');
        if (!row) return;
        const name = row.dataset.name;
        const pool = (searchScope === 'all' && siteGroups[activeGroupIdx])
            ? siteGroups[activeGroupIdx].hit
            : fakeMovies;
        const item = pool.find(m => m.name === name) || fakeMovies.find(m => m.name === name);
        if (item) openPlayPage(item);
    });

    /* ================= 悬浮弹窗逻辑 ================= */
    if (toggleSourceBtn && sourceSelectMask) {
        toggleSourceBtn.addEventListener('click', () => {
            sourceSelectMask.classList.add('show');
        });
        sourceSelectMask.addEventListener('click', e => {
            if (e.target === sourceSelectMask) {
                sourceSelectMask.classList.remove('show');
            }
        });
    }

    /* ================= 核心：直接扫描目录，抛弃后端 ================= */
    async function scanSourceDir() {
        try {
            const resp = await fetch('sources/', { cache: 'no-store' });
            if (!resp.ok) return [];
            const html = await resp.text();
            const found = [];
            // 从 InfinityFree 返回的目录列表 HTML 中提取 txt 文件名
            const re = /href=["']?([^"'*>]+?\.txt)/gi;
            let m;
            while ((m = re.exec(html)) !== null) {
                const rawName = decodeURIComponent(m[1].split('/').pop().split('?')[0]);
                if (rawName && found.indexOf(rawName) === -1) found.push(rawName);
            }
            // 按照数字前缀排序
            found.sort((a, b) => {
                const matchA = a.match(/^(\d+)/);
                const matchB = b.match(/^(\d+)/);
                const numA = matchA ? parseInt(matchA[1], 10) : 9999;
                const numB = matchB ? parseInt(matchB[1], 10) : 9999;
                return numA - numB;
            });
            return found;
        } catch (err) {
            return [];
        }
    }

    function createSourceCard(item) {
        const card = document.createElement('div');
        card.className = 'source-card';
        card.dataset.txt = item.txt || '';
        card.innerHTML = '<span class="card-text">' + esc(cleanName(item.name)) + '</span>';
        sourceList.appendChild(card);
        bindSourceCard(card);
        return card;
    }

    async function loadSources() {
        // 扫描文件夹，获取所有真实文件名
        const files = await scanSourceDir();
        
        sourceList.innerHTML = ''; 
        sourceItems = [];

        if (!files.length) {
            currentSourceName = '当前资源';
            mainContent.innerHTML = '<div class="empty-tip">未在 sources 目录找到 txt 文件</div>';
            return;
        }

        files.forEach((file, index) => {
            // 把显示名字变干净：去掉 "1_" 和 ".txt"
            let displayName = file.replace(/^\d+_/, '').replace(/\.txt$/i, '');
            const item = { id: 'src_' + index, name: displayName, txt: file };
            sourceItems.push(item);
            createSourceCard(item);
        });

        // 默认选中第一个源
        const firstCard = sourceList.querySelector('.source-card');
        if (firstCard) {
            currentTxtName = firstCard.dataset.txt || '';
            currentSourceName = cleanName(firstCard.querySelector('.card-text').textContent);
            activeSourceCard(firstCard);
            loadCurrentMovies();
        }
    }

    function bindSourceCard(card) {
        card.addEventListener('click', e => {
            e.stopPropagation();
            currentTxtName = card.dataset.txt || '';
            currentSourceName = cleanName(card.querySelector('.card-text').textContent);
            activeSourceCard(card);
            currentPage = 1;

            if (sourceSelectMask) sourceSelectMask.classList.remove('show');

            if (searchScope === 'all' && currentKw) {
                const cards = [].slice.call(sourceList.querySelectorAll('.source-card'));
                const idx = cards.indexOf(card);
                activeGroupIdx = idx >= 0 ? idx : 0;
                runSiteSearch(currentKw);
            } else if (searchScope === 'current' && kwInput.value.trim()) {
                const kwNow = kwInput.value.trim();
                mainContent.innerHTML = '<div class="loading-tip">正在检索当前资源…</div>';
                loadCurrentMovies(false).then(() => renderSearchResult(kwNow));
            } else {
                loadCurrentMovies();
            }
        });
    }

    /* ================= 顶部交互 ================= */
    function clearKeywordAndList() {
        kwInput.value = '';
        clearBtn.classList.add('hide');
        currentKw = '';
        currentPage = 1;
        activeGroupIdx = 0;
        siteGroups = [];
        loadCurrentMovies();
    }

    function goHome() {
        searchScope = 'current';
        scopeBtn.textContent = '当前资源';
        kwInput.placeholder = '输入影视名称搜索...';
        clearKeywordAndList();
    }

    homeTitle.addEventListener('click', goHome);
    function syncClearBtn() { clearBtn.classList.toggle('hide', !kwInput.value.trim()); }
    kwInput.oninput = syncClearBtn;
    clearBtn.onclick = clearKeywordAndList;

    scopeBtn.onclick = () => {
        searchScope = searchScope === 'current' ? 'all' : 'current';
        scopeBtn.textContent = searchScope === 'all' ? '全站搜索' : '当前资源';
        kwInput.placeholder = searchScope === 'all' ? '输入关键词检索全部源...' : '输入影视名称搜索...';
        if (currentKw) {
            currentPage = 1;
            activeGroupIdx = 0;
            if (searchScope === 'all') runSiteSearch(currentKw);
            else renderSearchResult(currentKw);
        }
    };

    modeBtn.onclick = () => {
        currentMode = currentMode === 'loose' ? 'strict' : 'loose';
        modeBtn.textContent = currentMode === 'loose' ? '🌙' : '☀️';
        modeBtn.title = modeLabel() + '搜索';
        if (currentKw) {
            currentPage = 1;
            if (searchScope === 'all') runSiteSearch(currentKw);
            else renderSearchResult(currentKw);
        }
    };

    searchBtn.onclick = doSearch;
    kwInput.onkeydown = e => { if (e.key === 'Enter') doSearch(); };

    /* ================= 页脚统计（保留） ================= */
    function todayKey() {
        const d = new Date();
        return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    }
    let midnightTimer = null;
    function scheduleMidnightRefresh() {
        if (midnightTimer) clearTimeout(midnightTimer);
        const now = new Date();
        const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 5, 0);
        midnightTimer = setTimeout(() => {
            try { sessionStorage.removeItem('visit_count_today'); } catch (err) {}
            updateVisitorCount();
        }, next - now);
    }
    async function updateVisitorCount() {
        const countEl = document.getElementById('visitorCount');
        if (!countEl) return;
        const CACHE_KEY = 'visit_count_today';
        const today = todayKey();
        let cached = null;
        try { cached = sessionStorage.getItem(CACHE_KEY); } catch (err) { cached = null; }
        if (cached !== null) {
            try {
                const obj = JSON.parse(cached);
                if (obj && obj.date === today) {
                    countEl.textContent = '今日访客：' + obj.count + ' 人';
                    scheduleMidnightRefresh();
                    return;
                }
            } catch (err) {}
        }
        try {
            const resp = await fetch('api/visit.php', { cache: 'no-store' });
            const data = await resp.json();
            const count = data.count || 0;
            countEl.textContent = '今日访客：' + count + ' 人';
            try { sessionStorage.setItem(CACHE_KEY, JSON.stringify({ date: today, count: count })); } catch (err) {}
        } catch (err) {
            countEl.textContent = '今日访客：-- 人';
        }
        scheduleMidnightRefresh();
    }
    function formatLoadTime() {
        const loadTime = document.getElementById('loadTime');
        if (!loadTime) return;
        const startTime = window.__pageStart || Date.now();
        loadTime.textContent = '页面加载：' + ((Date.now() - startTime) / 1000).toFixed(2) + 's';
    }

    let resizeTimer = null;
    window.addEventListener('resize', () => {
        if (resizeTimer) clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            if (mainContent.querySelector('.group-card')) fitGroupCards();
        }, 150);
    });

    loadSources();
    updateVisitorCount();
    syncClearBtn();
    formatLoadTime();
})();