<?php
/**
 * 公共配置 + 工具函数（sources.php / visit.php 共用）
 * 存储方式：JSON 文件，不使用数据库。
 * 兼容 PHP 5.6 / 7.x / 8.x
 */

/* ==================== 可改配置 ==================== */

// 数据目录：JSON 文件存放位置（建议放在网站根目录下的 data/，并在 data/.htaccess 里禁止直接访问）
if (!defined('DATA_DIR')) {
    define('DATA_DIR', dirname(__DIR__) . '/data');
}

define('SOURCES_FILE', DATA_DIR . '/sources.json');   // 源列表
define('VISITS_FILE',  DATA_DIR . '/visits.json');    // 访客统计
define('BACKUP_DIR',   DATA_DIR . '/backup');         // 源列表自动备份目录
define('BACKUP_KEEP',  5);      // 备份保留份数
define('HISTORY_KEEP', 30);     // 访客历史保留天数
define('MAX_SOURCES',  200);    // 源数量上限（防刷）
define('MAX_IPS_PER_DAY', 20000); // 单日记录的 IP 数上限（防内存/文件膨胀）

// 跨域：前端和接口同域部署时保持 false
define('ALLOW_CORS',   false);
define('CORS_ORIGIN',  '*');

// 写接口令牌：留空 = 不校验（前端目前不带令牌，与原版行为一致）。
// 以后要加鉴权：这里改成一段随机字符串，并让前端 POST 时带上请求头 X-Write-Token: 同样的值。
define('WRITE_TOKEN',  '');

// 是否信任反向代理的 X-Forwarded-For（用 nginx/CDN 加速时设 true）
define('TRUST_PROXY',  false);

// 是否过滤常见爬虫 UA（爬虫不计入今日访客）
define('FILTER_BOT',   true);

// 首次运行时自动生成的默认源列表（之后以 data/sources.json 为准）
$DEFAULT_SOURCES = array(
    array('id' => 'src_1', 'name' => '电影天堂', 'txt' => '电影天堂.txt', 'order' => 0),
    array('id' => 'src_2', 'name' => '高清资源', 'txt' => '高清资源.txt', 'order' => 1),
    array('id' => 'src_3', 'name' => '极速源',   'txt' => '极速源.txt',   'order' => 2),
);

/* ==================== 工具函数 ==================== */

if (!function_exists('json_out')) {
    /** 统一输出 JSON 并结束请求 */
    function json_out($data, $code = 200) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate');
        $flags = JSON_UNESCAPED_UNICODE;
        if (defined('JSON_PRETTY_PRINT')) $flags |= JSON_PRETTY_PRINT;
        echo json_encode($data, $flags);
        exit;
    }
}

if (!function_exists('json_fail')) {
    function json_fail($message, $code = 400) {
        json_out(array('success' => false, 'message' => $message), $code);
    }
}

if (!function_exists('handle_cors')) {
    function handle_cors() {
        if (!ALLOW_CORS) return;
        header('Access-Control-Allow-Origin: ' . CORS_ORIGIN);
        header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, X-Write-Token');
        if (isset($_SERVER['REQUEST_METHOD']) && strtoupper($_SERVER['REQUEST_METHOD']) === 'OPTIONS') {
            http_response_code(204);
            exit;
        }
    }
}

if (!function_exists('read_json_body')) {
    /** 读取请求体：优先 JSON，兼容表单提交 */
    function read_json_body() {
        $raw = file_get_contents('php://input');
        if ($raw !== false && trim($raw) !== '') {
            $data = json_decode($raw, true);
            if (is_array($data)) return $data;
            json_fail('请求体不是合法的 JSON');
        }
        return is_array($_POST) ? $_POST : array();
    }
}

if (!function_exists('check_write_token')) {
    function check_write_token() {
        if (WRITE_TOKEN === '') return;
        $got = '';
        if (isset($_SERVER['HTTP_X_WRITE_TOKEN'])) $got = $_SERVER['HTTP_X_WRITE_TOKEN'];
        elseif (isset($_POST['token'])) $got = $_POST['token'];
        if ($got !== WRITE_TOKEN) json_fail('无权操作：令牌不正确', 403);
    }
}

if (!function_exists('ensure_data_dir')) {
    function ensure_data_dir($dir) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        return is_dir($dir) && is_writable($dir);
    }
}

if (!function_exists('load_json_file')) {
    /** 读 JSON 文件，失败/不存在返回默认值 */
    function load_json_file($path, $default = array()) {
        if (!is_file($path)) return $default;
        $raw = @file_get_contents($path);
        if ($raw === false || trim($raw) === '') return $default;
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $default;
    }
}

if (!function_exists('save_json_file')) {
    /** 原子写入：先写临时文件再 rename，避免并发下写出半个文件 */
    function save_json_file($path, $data) {
        if (!ensure_data_dir(dirname($path))) return false;
        $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
        if (defined('JSON_PRETTY_PRINT')) $flags |= JSON_PRETTY_PRINT;
        $json = json_encode($data, $flags);
        if ($json === false) return false;
        $tmp = $path . '.tmp-' . getmypid() . '-' . uniqid();
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
            @unlink($tmp);
            return false;
        }
        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            return false;
        }
        @chmod($path, 0644);
        return true;
    }
}

if (!function_exists('acquire_lock')) {
    /** 文件锁：防止两个请求同时写同一个 JSON 互相覆盖 */
    function acquire_lock($name, $tries = 60) {
        if (!ensure_data_dir(DATA_DIR)) return null;
        $fp = @fopen(DATA_DIR . '/' . $name . '.lock', 'c');
        if (!$fp) return null;
        for ($i = 0; $i < $tries; $i++) {
            if (flock($fp, LOCK_EX | LOCK_NB)) return $fp;
            usleep(50000); // 50ms
        }
        fclose($fp);
        return null;
    }
}

if (!function_exists('release_lock')) {
    function release_lock($fp) {
        if (is_resource($fp)) {
            @flock($fp, LOCK_UN);
            @fclose($fp);
        }
    }
}

if (!function_exists('clean_text')) {
    /** 去掉控制字符、首尾空格，限制长度 */
    function clean_text($str, $maxLen = 100) {
        if (!is_scalar($str)) return '';
        $s = (string)$str;
        // 注意：这里不加 /u 修饰符，避免非法 UTF-8 输入时 preg_replace 返回 null
        $s = preg_replace('/[\x00-\x1F\x7F]/', '', $s);
        $s = trim($s);
        if ($s === '') return '';
        if (function_exists('mb_substr')) {
            $s = mb_substr($s, 0, $maxLen, 'UTF-8');
        } elseif (strlen($s) > $maxLen * 3) {
            $s = substr($s, 0, $maxLen * 3);
        }
        // 截断可能把多字节字符切一半，这里抹掉非法字节，保证 json_encode 不会失败
        if (function_exists('mb_check_encoding') && !mb_check_encoding($s, 'UTF-8')) {
            $s = function_exists('mb_convert_encoding') ? mb_convert_encoding($s, 'UTF-8', 'UTF-8') : '';
        }
        return $s;
    }
}

if (!function_exists('clean_txt_name')) {
    /**
     * 清洗 TXT 文件名：只保留文件名部分，挡掉目录穿越（../）和非法字符；
     * 没写扩展名时自动补 .txt（与前端 fetch('sources/xxx.txt') 的用法保持一致）
     */
    function clean_txt_name($raw) {
        $name = clean_text($raw, 120);
        if ($name === '') return '';
        $name = str_replace('\\', '/', $name);
        $parts = explode('/', $name);
        $name = trim((string)end($parts));
        if ($name === '' || strpos($name, '..') !== false) return '';
        if (preg_match('/[\/\\\\:*?"<>|]/', $name)) return '';
        if (!preg_match('/\.txt$/i', $name)) $name .= '.txt';
        return $name;
    }
}

if (!function_exists('client_ip')) {
    function client_ip() {
        if (TRUST_PROXY && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $parts = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($parts[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
        if (TRUST_PROXY && !empty($_SERVER['HTTP_X_REAL_IP'])) {
            $ip = trim($_SERVER['HTTP_X_REAL_IP']);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    }
}

if (!function_exists('is_bot')) {
    function is_bot() {
        if (!FILTER_BOT) return false;
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
        if ($ua === '') return true; // 没有 UA 的一般是脚本抓取，不计入访客
        $bots = array('bot', 'spider', 'crawl', 'slurp', 'curl', 'wget', 'python', 'requests',
                      'httpclient', 'http-client', 'okhttp', 'java', 'libwww', 'scanner', 'zgrab',
                      'go-http-client', 'node-fetch', 'axios', 'postman', 'headless', 'phantom',
                      'selenium', 'fedex', 'yandex', 'sogou', '360splice');
        foreach ($bots as $b) {
            if (strpos($ua, $b) !== false) return true;
        }
        return false;
    }
}

if (!function_exists('ip_hash')) {
    /** 只存哈希，不落原始 IP */
    function ip_hash($ip) {
        return substr(sha1('visit-salt|' . $ip), 0, 24);
    }
}
