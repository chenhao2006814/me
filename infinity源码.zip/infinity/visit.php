<?php
/**
 * 今日访客统计接口（JSON 文件存储，无数据库）
 * 接口地址与返回字段与原版一致：前端只读 data.count。
 *
 * GET api/visit.php
 *   返回：{"success":true,"count":8,"date":"2026-11-18","total":126,"is_new":true}
 *     count  = 今日访客数（同一 IP 当天只算 1 次）
 *     total  = 历史累计访客数
 *     date   = 统计日期（服务器时区 Asia/Shanghai）
 *
 * 数据文件：data/visits.json
 * 说明：只保存 IP 的哈希值，不落原始 IP；跨天自动把上一天的数字归档到 history，
 *       保留 HISTORY_KEEP 天，文件不会无限增大。
 */

require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Shanghai');

/* ==================== 内部函数（先定义，后调用） ==================== */

if (!function_exists('default_visits')) {
    function default_visits() {
        return array(
            'date'    => date('Y-m-d'),
            'count'   => 0,
            'total'   => 0,
            'ips'     => array(),
            'history' => array(),
        );
    }
}

if (!function_exists('normalize_visits')) {
    /** 把磁盘上的数据补齐成固定结构，缺字段/坏字段一律给默认值 */
    function normalize_visits($data) {
        if (!is_array($data)) $data = array();
        $out = default_visits();

        $out['date']  = isset($data['date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$data['date'])
            ? (string)$data['date'] : date('Y-m-d');
        $out['count'] = isset($data['count']) && is_numeric($data['count']) ? (int)$data['count'] : 0;
        $out['total'] = isset($data['total']) && is_numeric($data['total']) ? (int)$data['total'] : 0;
        $out['ips']     = isset($data['ips'])     && is_array($data['ips'])     ? $data['ips']     : array();
        $out['history'] = isset($data['history']) && is_array($data['history']) ? $data['history'] : array();

        return $out;
    }
}

if (!function_exists('roll_day')) {
    /** 跨天归档：把上一天的数字写进 history 并重置当日计数 */
    function roll_day(&$data, $today) {
        if ($data['date'] === $today) return;

        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$data['date'])) {
            $data['history'][(string)$data['date']] = (int)$data['count'];
            // 只保留最近 HISTORY_KEEP 天
            if (count($data['history']) > HISTORY_KEEP) {
                ksort($data['history']);
                $data['history'] = array_slice($data['history'], -HISTORY_KEEP, null, true);
            }
        }

        $data['date']  = $today;
        $data['count'] = 0;
        $data['ips']   = array();
    }
}

/* ==================== 路由 ==================== */

handle_cors();
header('Cache-Control: no-store, no-cache, must-revalidate');

$today = date('Y-m-d');
$hash  = ip_hash(client_ip());
$bot   = is_bot();

$lock = acquire_lock('visits');
if ($lock === null) {
    // 拿不到锁也不影响展示：直接读文件返回当前数字，不写库
    $data = normalize_visits(load_json_file(VISITS_FILE, default_visits()));
    roll_day($data, $today);
    json_out(array(
        'success' => true,
        'count'   => (int)$data['count'],
        'date'    => $today,
        'total'   => (int)$data['total'],
        'is_new'  => false,
    ));
}

$data = normalize_visits(load_json_file(VISITS_FILE, default_visits()));
roll_day($data, $today);

$isNew = false;
if (!$bot && !isset($data['ips'][$hash])) {
    // 单日 IP 记录数封顶，防止被刷爆文件
    if (count($data['ips']) < MAX_IPS_PER_DAY) {
        $data['ips'][$hash] = time();
        $data['count'] = (int)$data['count'] + 1;
        $data['total'] = (int)$data['total'] + 1;
        $isNew = true;
    }
}

$ok = save_json_file(VISITS_FILE, $data);
release_lock($lock);

json_out(array(
    'success' => true,
    'count'   => (int)$data['count'],
    'date'    => $today,
    'total'   => (int)$data['total'],
    'is_new'  => $isNew,
    'saved'   => $ok,   // false = data 目录不可写，数字本次未持久化
));
